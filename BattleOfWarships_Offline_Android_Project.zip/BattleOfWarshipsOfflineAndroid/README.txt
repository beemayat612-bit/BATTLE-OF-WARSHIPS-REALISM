BATTLE OF WARSHIPS: REALISM — OFFLINE ANDROID PROJECT

This project wraps the 3D HTML game in an Android WebView.
The game and Three.js library are stored inside the APK, so the installed
game does not need internet access to play.

BUILD ON GITHUB (phone-friendly):
1. Upload the CONTENTS of this folder into the root of your GitHub repository.
   Keep the .github/workflows/build-apk.yml file and its folder structure.
2. Open the repository on GitHub.
3. Tap Actions.
4. Open "Build offline Android APK".
5. Tap "Run workflow" (or wait for the push build to finish).
6. Open the completed run and download the artifact named
   "BattleOfWarships-Offline-APK".
7. Extract the artifact ZIP and install app-debug.apk on your Android phone.

NOTES:
- The workflow downloads the Three.js library during BUILD only.
- The resulting APK contains that library locally and does not request
  Android internet permission.
- This is a debug APK for testing, not a Play Store release.
- The APK has not yet been compiled or tested on a physical phone.
